/**
 * CLIPIA V4 — Assistant d'installation : ce qui est prêt, ce qui manque, et comment l'obtenir.
 * Aucune clé ne peut être « obtenue » à la place de la personne (elle exige son compte) :
 * Clipia détecte, guide pas à pas, teste la clé collée, et installe ce qui s'installe sans compte.
 */
import { spawn, spawnSync } from 'node:child_process';
import { PROVIDERS, byId } from '../providers/registry.js';
import { credential } from '../providers/gateway.js';
import { etatOutils } from '../lib/env.js';
import { ollamaPresent } from '../providers/installeur.js';
import { store } from '../lib/store.js';
import * as ext from './extension.js';
import { profil } from './personnalite.js';

const a = (id) => { const p = byId(id); if (!p) return false; try { const c = credential(p); return Boolean(c) && c !== 'libre' && c !== 'local'; } catch { return false; } };
const trouve = (cmd, args = ['--version']) => { try { const r = spawnSync(cmd, args, { timeout: 8000, shell: process.platform === 'win32' }); return r.status === 0 ? String(r.stdout).trim().split('\n')[0].slice(0, 80) : ''; } catch { return ''; } };

export async function etat() {
  const oll = await ollamaPresent().catch(() => ({ ok: false }));
  const modeleQwen = (oll.modeles || []).some(m => /qwen/i.test(m.nom));
  const outils = etatOutils();
  const ignores = store.setting('installation.ignores') || [];
  const etapes = [
    { id: 'groq', fait: a('groq'), titre: 'Cerveau rapide : Groq (gratuit)', optionnel: false },
    { id: 'local', fait: modeleQwen, titre: 'Cerveau local : Qwen (hors ligne, sans clé)', optionnel: false, info: { ollama: oll.ok } },
    { id: 'claude', fait: a('anthropic'), titre: 'Claude (Anthropic) — raisonnement avancé', optionnel: true },
    { id: 'claudecode', fait: Boolean(trouve('claude')), titre: 'Claude Code — coder dans ton ordinateur', optionnel: true },
    { id: 'images', fait: PROVIDERS.some(p => (p.modalities || []).includes('image') && (p.sansCle || a(p.id))), titre: 'Images', optionnel: false },
    { id: 'video', fait: outils.present, titre: 'Vidéos (ffmpeg)', optionnel: false },
    { id: 'musique', fait: PROVIDERS.some(p => (p.modalities || []).includes('musique') && (p.sansCle || a(p.id))), titre: 'Musique', optionnel: true },
    { id: 'voix', fait: true, titre: 'Voix naturelle', optionnel: false },
    { id: 'code', fait: true, titre: 'Coder et se coder elle-même', optionnel: false },
    { id: 'agents', fait: true, titre: 'Agents, workflows, projets', optionnel: false },
    { id: 'ordinateur', fait: true, titre: 'Contrôle de l\'ordinateur (clavier, souris, applications)', optionnel: true },
    { id: 'chrome', fait: ext.connectee(), titre: 'Extension Chrome', optionnel: true }
  ].map(e => ({ ...e, ignore: ignores.includes(e.id) }));
  const cerveau = etapes.find(e => e.id === 'groq').fait || etapes.find(e => e.id === 'local').fait || PROVIDERS.some(p => p.tier === 'cloud-gratuit' && a(p.id));
  return { etapes, cerveau, termine: Boolean(store.setting('installation.termine')) || process.env.CLIPIA_SANS_ASSISTANT === '1', configure: Boolean(profil().configure) || process.env.CLIPIA_SANS_ASSISTANT === '1', plateforme: process.platform, extension: { dossier: ext.DOSSIER, connectee: ext.connectee() } };
}
export const ignorer = (id, oui = true) => {
  const l = new Set(store.setting('installation.ignores') || []); oui ? l.add(id) : l.delete(id);
  store.setting('installation.ignores', [...l]); return [...l];
};
export const terminer = () => store.setting('installation.termine', true);

/** Installe Claude Code (npm). Appelé seulement après un clic dans l'interface. */
export function installerClaudeCode(sortie) {
  return new Promise((ok, ko) => {
    if (!trouve('npm')) return ko(new Error('npm est introuvable : installe Node.js (nodejs.org) puis réessaie.'));
    const p = spawn('npm', ['install', '-g', '@anthropic-ai/claude-code'], { shell: process.platform === 'win32' });
    let err = '';
    p.stdout.on('data', d => sortie?.(String(d).trim().slice(-160)));
    p.stderr.on('data', d => { err += d; sortie?.(String(d).trim().slice(-160)); });
    p.on('error', ko);
    p.on('close', c => c === 0 ? ok(true) : ko(new Error(err.trim().slice(-300) || 'npm a échoué (code ' + c + ').')));
  });
}
