# Clipia sur Android et iPhone

Clipia s'installe sur le téléphone comme une application (icône sur l'écran d'accueil, plein écran).
Le moteur tourne sur ton ordinateur ; le téléphone sert d'écran, de micro et de clavier.

## 1. Sur l'ordinateur
1. Installe Clipia (Windows, Mac ou Linux) comme d'habitude.
2. Windows portable : double-clique `Clipia-Telephone.bat` (dans le dossier Clipia-Portable).
   Mac/Linux : lance `clipia-telephone.sh` dans le dossier de l'application.
3. La fenêtre affiche l'**adresse** (ex. http://192.168.1.20:8787) et un **code d'accès à 6 chiffres**.
   Autorise le pare-feu si Windows le demande (réseau privé).

## 2. Android (Chrome)
1. Téléphone sur le **même Wi-Fi**. Ouvre l'adresse dans Chrome, entre le code.
2. Menu ⋮ → **Installer l'application** (ou « Ajouter à l'écran d'accueil »).

## 3. iPhone (Safari)
1. Ouvre l'adresse dans **Safari**, entre le code.
2. Bouton Partager → **Sur l'écran d'accueil** → Ajouter.

## Remarques
- Le code protège tes clés : sans lui, rien ne s'affiche. Ne partage pas l'adresse sur un Wi-Fi public.
- Le mode appel « Dis Clipia » dépend du navigateur du téléphone (Chrome Android : oui ; iPhone : limité).
- Il n'existe pas de fichier .apk / .ipa : un .ipa exige un Mac avec Xcode et un compte développeur Apple (99 €/an), et un .apk l'outillage Android, indisponibles ici. Cette installation par navigateur fait la même chose pour toi, sans store. Si tu veux ensuite un vrai .apk, il pourra être construit sur ton PC avec Android Studio.
