#!/bin/sh
# Lance Clipia accessible depuis ton telephone (meme Wi-Fi). Un code d'acces s'affiche.
cd "$(dirname "$0")"
export HOST=0.0.0.0
echo "Adresse a ouvrir sur le telephone : http://$(hostname -I 2>/dev/null | awk '{print $1}' || ipconfig getifaddr en0):8787"
exec node server/index.js
