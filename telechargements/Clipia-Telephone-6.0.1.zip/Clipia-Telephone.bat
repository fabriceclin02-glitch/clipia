@echo off
rem Lance Clipia accessible depuis ton telephone (meme Wi-Fi). Un code d'acces s'affiche.
cd /d "%~dp0"
set HOST=0.0.0.0
echo.
echo  Adresse a ouvrir sur le telephone (meme Wi-Fi) :
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo     http:%%a:8787
echo.
if exist runtime\node.exe (runtime\node.exe app\server\index.js) else (node server\index.js)
pause
