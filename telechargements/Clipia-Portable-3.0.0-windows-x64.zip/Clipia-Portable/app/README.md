<div align="center">

# CLIPIA
### Studio créatif IA — CLENDAX
*Une idée. Tout est possible.*

</div>

---

Clipia transforme une musique en clip vidéo complet, génère vos visuels, écrit vos textes et publie sur vos plateformes. Il parle à **37 moteurs IA** — payants, gratuits, ou tournant entièrement sur votre machine — et se branche à **29 services** via OAuth.

**Il fonctionne sans aucun abonnement IA.** Ollama + ComfyUI + whisper.cpp + FFmpeg en local, et vous produisez des clips illimités, gratuitement, hors ligne.

---

## Démarrer en 30 secondes

```bash
node server/index.js
```

Puis ouvrez **http://127.0.0.1:8787**. Aucune installation npm, aucune dépendance : Node 20+ suffit.

Si vous préférez un installateur qui met aussi Node, FFmpeg et Ollama en place :

| Système | Commande |
|---|---|
| Windows | clic droit sur `installers\installer-windows.ps1` → Exécuter avec PowerShell |
| macOS / Linux | `bash installers/installer-unix.sh` |
| Docker | `docker compose up -d` (Clipia + Ollama inclus) |

---

## Ce que fait Clipia

### Musique → Clip
Déposez un MP3. Clipia enchaîne sept étapes :

1. **Analyse** — durée, BPM, temps forts, via FFmpeg
2. **Paroles** — transcription horodatée mot à mot (Whisper, AssemblyAI, Deepgram ou whisper.cpp local)
3. **Scénario** — un LLM découpe le morceau en plans visuels datés
4. **Visuels** — génération de chaque plan (Flux, SDXL, DALL·E, ou ComfyUI local)
5. **Animation** — image→vidéo (Luma, Runway, Kling) ou **Ken Burns local, gratuit**
6. **Montage** — assemblage synchronisé, karaoké incrusté, étalonnage, vignettage
7. **Export** — 16:9 YouTube · 9:16 TikTok/Shorts/Reels · 1:1 Instagram · 2.35:1 cinéma

### Le reste du studio
- **Klipia, l'assistant** — conversation streamée avec n'importe quel modèle
- **Image et 3D** — visuels, pochettes, maquettes de t-shirts, fiches produit
- **Vidéo** — plans générés à la demande
- **Paroles et voix** — transcription karaoké, voix off multilingue
- **Workflows** — enchaînements automatiques : clip → extrait vertical → publication partout
- **Médiathèque, file de tâches, quotas, abonnements**

---

## Les 37 moteurs IA

<table>
<tr><th>Cloud</th><th>Local — gratuit</th></tr>
<tr valign="top"><td>

OpenAI · Anthropic Claude · Google Gemini · Mistral · DeepSeek · Groq · OpenRouter · Together · Fireworks · xAI Grok · Perplexity · Cohere · Qwen · Hugging Face · Stability · fal.ai · Replicate · Runway · Luma · ElevenLabs · AssemblyAI · Deepgram · Suno

</td><td>

**Ollama** · LM Studio · llama.cpp · vLLM · Jan.ai · LocalAI · Text-Gen WebUI · **ComfyUI** · Automatic1111 · **whisper.cpp** · **FFmpeg**

</td></tr>
</table>

Ajouter un moteur n'est qu'une ligne dans `server/providers/registry.js` : tout serveur compatible OpenAI marche sans écrire une seule ligne de code supplémentaire.

---

## Les 29 connecteurs

| Groupe | Services |
|---|---|
| **Diffusion** | YouTube, TikTok, Instagram, Facebook, X, Twitch, LinkedIn, Pinterest, Reddit |
| **Musique** | Spotify, SoundCloud, Bandcamp, distribution |
| **Stockage** | Google Drive, Dropbox, Notion, S3 (et R2, B2, MinIO) |
| **Boutique** | Etsy, Shopify, Printful |
| **Paiement** | Stripe, PayPal, Lemon Squeezy |
| **Outils** | GitHub, Discord, Slack, webhook générique, SMTP, serveur MCP |

Un seul moteur OAuth générique les gère tous (PKCE, rafraîchissement de jetons, stockage chiffré). Déclarez cette URL de redirection dans chaque console développeur :

```
http://127.0.0.1:8787/api/connectors/callback
```

---

## Sécurité

- **Coffre AES-256-GCM** — les clés sont chiffrées au repos dans `data/vault.enc`. Le navigateur ne reçoit jamais une valeur, seulement un indice masqué (`sk-a••••••••7890`).
- **Clé maîtresse** générée au premier lancement dans `data/secrets.json`, en permissions `600`.
- **Aucune clé dans le front** — tous les appels aux fournisseurs partent du serveur.
- **Webhooks Stripe** vérifiés par HMAC avec comparaison à temps constant et fenêtre de 5 minutes.
- **Webhooks sortants** signés `X-Clipia-Signature`.

---

## Déploiement

| Cible | Dossier | Commande |
|---|---|---|
| Serveur / VPS | racine | `node server/index.js` derrière Caddy ou Nginx |
| Docker | racine | `docker compose up -d` |
| Windows / Mac / Linux | `desktop/` | `npm install && npm run build:win` (ou `:mac`, `:linux`) |
| Android / Play Store | `android/` | voir `android/README.md` |
| Navigateur (PWA) | — | menu du navigateur → « Installer l'application » |

---

## API

Tout ce que fait l'interface passe par HTTP — pilotez Clipia depuis n8n, Make, un script ou un agent IA.

```bash
curl -X POST http://127.0.0.1:8787/api/taches \
  -H "content-type: application/json" \
  -d '{"type":"clip","payload":{
        "audioPath":"/chemin/morceau.mp3",
        "style":"néon nocturne, grain argentique",
        "ratio":"tiktok",
        "llm":{"provider":"ollama","model":"llama3.3"},
        "imageProvider":"comfyui"}}'
```

Routes principales : `/api/etat` · `/api/fournisseurs` · `/api/chat` (SSE) · `/api/coffre` · `/api/connecteurs` · `/api/taches` (+ `/flux` en SSE) · `/api/medias` · `/api/abonnement` · `/api/webhooks/stripe`

---

## Structure

```
clipia/
├─ server/              Backend Node, zéro dépendance
│  ├─ lib/              env · coffre chiffré · stockage
│  ├─ providers/        registre 37 moteurs · passerelle · média
│  ├─ connectors/       manifestes 29 services · OAuth · publication
│  ├─ pipelines/        musique → clip
│  ├─ jobs/             file de tâches + exécuteurs
│  └─ billing/          abonnements Stripe
├─ web/                 Interface du studio (PWA)
├─ desktop/             Electron — Windows, macOS, Linux
├─ android/             Capacitor — Play Store
├─ installers/          Scripts PowerShell et Bash
├─ docs/                Architecture, confidentialité, démarrage
└─ data/                Coffre, base, médias (jamais versionné)
```

---

<div align="center">

**Clin Fabrice — CLENDAX** · Flize, Ardennes
[fabriceclin02@gmail.com](mailto:fabriceclin02@gmail.com)

</div>
